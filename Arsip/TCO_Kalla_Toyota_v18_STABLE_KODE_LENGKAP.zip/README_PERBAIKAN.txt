# TCO Kalla Toyota – v18 (1 November 2026)

## Tujuan
Paket lengkap **kode** website katalog informasi harga TCO Juli 2026 untuk 16 unit, tanpa mengganti foto yang sudah disetujui. Bukan website transaksi. Data harga bersumber dari file detail-tco-prices.js yang sudah digunakan sebelumnya.

## Perbaikan utama
- Navbar index dan detail menggunakan markup sama dan `shared-navbar.css`; logo dan menu memiliki posisi identik. Desktop 1440px diuji: menu pada x=471,5px, lebar 450px; logo kiri x=52px pada kedua halaman.
- Agya: 7 warna hero (default putih), 9 kartu part, Explorer putih depan-belakang, hotspot hanya pada titik yang punya koordinat. Warna hero tidak mengubah Explorer.
- Kartu part **tidak punya popup saat hover**; popup detail hanya hotspot pada model.
- Popup dibatasi lebar 350px di desktop, ditampilkan pada area bawah layar untuk mobile, dan tidak menutupi header sticky.
- Unit selain Agya menggunakan foto lama sebagai referensi (jika ada) dan tidak mengklaim warna putih. Pemilih warna dan hotspot yang belum didukung aset/kalibrasi disembunyikan.
- Gambar part tanpa kecocokan nama TCO yang jelas tidak dipaksakan; tampil placeholder "Foto part belum tersedia".
- Harga yang mengikuti Part Bulletin atau perlu verifikasi tetap diberi penanda, tidak dibuat-buat.

## Cara memasang
1. **Cadangkan** seluruh proyek `tco-toyota` yang sedang berjalan.
2. Ekstrak isi ZIP ke root proyek dan timpa 11 file kode yang namanya sama.
3. **Pertahankan folder `assets/` milikmu**. ZIP ini tidak menyertakan gambar unit/part/poster agar aset lama tidak tertimpa.
4. Jalankan server statis dari root proyek: `python -m http.server 8000` dan buka `http://localhost:8000/index.html`.
5. Uji `detail.html?unit=agya`, `detail.html?unit=calya`, dan 16 unit dengan tombol panah. Periksa desktop dan mobile; hard refresh `Ctrl+Shift+R`.

## Perlu dikerjakan kemudian
- Foto warna, foto part, hotspot unit lain (15 unit) belum tersedia/terkalibrasi lengkap.
- Foto referensi lama dapat berbeda grade/tahun; jangan anggap sudah terverifikasi.
- Periksa SKU/grade dan harga yang belum terverifikasi dengan PDF master sebelum publikasi.

## Status integrasi Google Drive
File asli di Google Drive sebelumnya tersinkron sebagian karena beberapa operasi penggantian file ditolak oleh konektor. ZIP ini disiapkan sebagai **satu paket konsisten** untuk pemasangan manual. Jangan menganggap file `index.html`/`detail.html` lama di Drive sudah memakai navbar v18 sampai seluruh file dari ZIP diterapkan.

## Pengujian yang dilakukan
- Sintaks Node.js untuk semua file JS: lulus.
- Data: 16 model; 16 daftar unit TCO; 9 kartu Agya; 7 warna; 6 part Agya punya posisi hotspot; source explorer front/rear putih.
- Header HTML dan CSS di Chromium (tanpa mengambil sumber eksternal): posisi navbar dan logo identik pada 1440px.
- Interaksi DOM (tanpa pemuatan gambar eksternal): kartu tidak memicu popup, hotspot memicu popup via event; navigasi dan hamburger mobile berjalan; tidak ada error JS pada uji tersebut.
- Akses URL localhost secara penuh dan pembebanan gambar riil dibatasi lingkungan pengujian, sehingga tampilan final bersama seluruh aset di komputer pengguna **belum diklaim tervalidasi**.
