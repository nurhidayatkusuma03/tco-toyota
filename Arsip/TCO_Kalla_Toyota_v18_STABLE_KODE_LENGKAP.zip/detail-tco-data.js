/* Data tampilan; harga tidak diketik ulang, diambil dari detail-tco-prices.js */
window.TCO_DETAIL_META = {
  'agya': { title:'NEW|AGYA', tagline:'Move with your style.', heroColor:'white' },
  'calya': {title:'CALYA',tagline:'For every journey.'},
  'raize': {title:'RAIZE',tagline:'Ready for your next move.'},
  'rush': {title:'RUSH',tagline:'Ready for adventure.'},
  'yaris-cross': {title:'YARIS|CROSS',tagline:'Explore more possibilities.'},
  'fortuner': {title:'FORTUNER',tagline:'Bold in every detail.'},
  'land-cruiser': {title:'LAND CRUISER|300',tagline:'Crafted for every journey.'},
  'avanza': {title:'NEW|AVANZA',tagline:'For the journeys that matter.'},
  'veloz': {title:'VELOZ|HYBRID',tagline:'Style meets innovation.'},
  'innova-zenix': {title:'INNOVA|ZENIX',tagline:'Elevate Your Next Journey.'},
  'innova-reborn': {title:'INNOVA|REBORN',tagline:'Experience every journey.'},
  'voxy': {title:'VOXY',tagline:'Refined for your journey.'},
  'alphard': {title:'ALPHARD',tagline:'A new level of comfort.'},
  'vellfire': {title:'VELLFIRE',tagline:'Elevated in every detail.'},
  'hilux-d-cab': {title:'HILUX',tagline:'Built for what comes next.'},
  'hilux-rangga': {title:'HILUX|RANGGA',tagline:'Ready for every business.'}
};
const AGYA_COLORS = [
  ['white','White','#f7f7f5'], ['black','Black','#17191b'],
  ['red','Red','#c32335'], ['yellow','Yellow','#f9d416'],
  ['silver','Silver Metallic','#b7bec3'], ['gray','Gray Metallic','#5d656b'],
  ['orange','Orange','#e77c24']
];
window.TCO_COLOR_ASSETS = Object.fromEntries(
  (window.CATALOG || []).map(m=>[
    m.slug,
    m.slug === 'agya'
    ? AGYA_COLORS.map(([key,name,hex])=>({key,name,hex,front:`assets/vehicles/agya/colors/front-${key}.png`}))
    : [] // Unit lain memakai foto referensi yang sudah ada; tidak mengklaim warna putih.
  ])
);
/* Foto explorer bersifat TETAP, tidak terpengaruh selected color pada hero */
window.TCO_EXPLORER_IMAGES = Object.fromEntries(
  (window.CATALOG || []).map(m=>[
    m.slug, m.slug === 'agya'
      ? {front:'assets/vehicles/agya/colors/front-white.png',rear:'assets/vehicles/agya/colors/rear-white.png'}
      : {front:m.frontImage||m.main||'',rear:m.rearImage||''}
  ])
);
/* Semua hotspot Agya merujuk koordinat relatif terhadap raster asli (bukan frame). 
   Jika PNG baru memiliki crop berbeda, set ulang posisi lewat fungsi kalibrasi. */
window.TCO_EXPLORER_POSITIONS = {
  agya: Object.fromEntries((window.TCO_PRICES?.agyaCards||[]).map(p=>[p.id,p.pos||{}]))
};
