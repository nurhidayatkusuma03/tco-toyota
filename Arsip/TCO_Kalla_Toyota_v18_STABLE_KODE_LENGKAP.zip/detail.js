/* TCO Kalla Toyota v15 — katalog harga, bukan transaksi */
(() => {
  'use strict';
  const $ = (s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const H = value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const rupiah = n => typeof n==='number' ? 'Rp'+n.toLocaleString('id-ID') : 'Harga belum tercantum';
  const slugify = s => String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  const trim = (n,min,max)=>Math.max(min,Math.min(max,n));
  const CATALOG=Array.isArray(window.CATALOG)?window.CATALOG:[];
  const META=window.TCO_DETAIL_META||{};
  const COLORS=window.TCO_COLOR_ASSETS||{};
  const VIEWS=window.TCO_EXPLORER_IMAGES||{};
  const PRICE=window.TCO_PRICES||{units:{},agyaCards:[]};
  const pointCoords=window.TCO_EXPLORER_POSITIONS||{};
  if(!CATALOG.length){$('#hero-title').textContent='Katalog tidak tersedia — periksa data.js';return}
  const initial=new URLSearchParams(location.search).get('unit')||'agya';
  let idx=Math.max(0,CATALOG.findIndex(x=>x.slug===initial));
  let tab='all', chosenColor='white', focusedPart=null, hideTimer=0;
  const hoverDevice=window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  // Navbar seluler identik dengan halaman utama.
  const menuButton=$('#menu-button'),mobileNav=$('#mobile-nav');
  menuButton?.addEventListener('click',()=>{
    mobileNav.hidden=!mobileNav.hidden;
    menuButton.setAttribute('aria-expanded',String(!mobileNav.hidden));
  });
  $$('#mobile-nav a').forEach(a=>a.addEventListener('click',()=>{
    mobileNav.hidden=true;menuButton?.setAttribute('aria-expanded','false');
  }));
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&mobileNav&&!mobileNav.hidden){mobileNav.hidden=true;menuButton?.setAttribute('aria-expanded','false');menuButton?.focus()}});
  // Fallback navigasi seluler untuk HTML lama tanpa komponen menu-button.
  if(!menuButton){
    const header=$('header.topbar');
    if(header){
      const menu=document.createElement('button');menu.type='button';menu.className='detail-menu-button';menu.setAttribute('aria-label','Buka menu');menu.setAttribute('aria-expanded','false');
      menu.innerHTML='<span></span><span></span><span></span>';
      const nav=document.createElement('nav');nav.className='detail-mobile-nav';nav.hidden=true;nav.setAttribute('aria-label','Navigasi seluler');
      nav.innerHTML='<a href="index.html#home">Home</a><a href="index.html#katalog">Katalog</a><a href="index.html#contact">Hubungi Kami</a>';
      header.appendChild(menu);header.appendChild(nav);
      menu.addEventListener('click',()=>{nav.hidden=!nav.hidden;menu.setAttribute('aria-expanded',String(!nav.hidden))});
      nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.hidden=true;menu.setAttribute('aria-expanded','false')}));
    }
  }
  const m=()=>CATALOG[idx];
  const meta=()=>META[m().slug]||{};
  const colors=()=>m().slug==='agya'?(COLORS[m().slug]||[]):[];
  const color=()=>colors().find(c=>c.key===chosenColor)||colors()[0];

  // Image fallback is only used for legacy images. Failed explorer images do not retain dots.
  function imageOrFallback(img,src,legacy='',onFail=null){
    if(!src){img.hidden=true;if(onFail)onFail();return}
    img.onerror=()=>{
      if(legacy && img.src !== new URL(legacy, location.href).href){ img.onerror=()=>{img.hidden=true;if(onFail)onFail()};img.src=legacy; }
      else{img.hidden=true;if(onFail)onFail()}
    };
    img.onload=()=>{img.hidden=false};
    img.src=src;
  }
  const partPhoto=id=>`assets/vehicles/${m().slug}/parts/${id}.png`;
  const agyaPart=p=>({ ...p, image:partPhoto(p.id), partNumber:p.partNumber||'', note:p.status==='verify'?'Kecocokan dengan nama part harga satuan perlu diverifikasi.':p.status==='bulletin'?'Harga mengikuti Part Bulletin.':p.components?'Harga adalah total komponen, bukan paket tersendiri.':'' });
  function allParts(){
    if(m().slug==='agya')return (PRICE.agyaCards||[]).map(agyaPart);
    // Cocokkan hanya nama part yang sama persis dengan katalog visual lama.
    // Jangan tempelkan foto part berbeda hanya karena urutan atau kata kuncinya mirip.
    const visualParts=Array.isArray(m().parts)?m().parts:[];
    return (PRICE.units?.[m().slug]||[]).map((p,i)=>{
      const reference=visualParts.find(v=>slugify(v.title||'')===slugify(p.name||''));
      return {
        id:`${slugify(p.name)}-${slugify(p.sku)}`,title:p.name,
        kind:/seat|dash|fragrance|horn|mat|net|organizer|dvr|purifier/i.test(p.name)?'interior':'exterior',
        image:reference?.image||null,
        photoStatus:reference?'Foto katalog visual referensi; kesesuaian tahun/grade perlu diverifikasi.':'',
        description:'Informasi komponen berdasarkan daftar TCO Juli 2026. Kesesuaian grade perlu dicek pada tabel sumber.',
        price:p.price,partNumber:p.sku,grades:[],pos:{},sourcePage:p.page,
        note:'Lihat kecocokan grade pada dokumen TCO.'
      };
    });
  }
  function grade(p){return (p.grades||[]).map(x=>`<span>${H(x)}</span>`).join('')}
  function effectiveSKU(p){
    // SKU di daftar harga Bumper Spoiler/SideSkirt BUKAN SKU GR Aeromudguard yang sudah terverifikasi.
    if(p.status==='verify')return '';
    return p.partNumber||'';
  }
  function priceString(p){
    if(p.status==='verify')return 'Harga belum terverifikasi';
    if(p.status==='bulletin')return p.priceLabel||'Mengikuti Part Bulletin';
    return rupiah(p.price);
  }
  function detailNote(p){
    if(p.status==='verify')return `Harga pembanding: ${rupiah(p.referencePrice)} untuk ${p.referenceName||'nama part berbeda'}. Belum boleh ditetapkan sebagai harga ${displayTitle(p)} tanpa verifikasi part number.`;
    if(p.components)return 'Penjumlahan tiga komponen: '+p.components.map(x=>`${x.name} ${rupiah(x.price)}`).join(' + ')+'.';
    return p.note||'';
  }
  function displayTitle(p){return p.title||p.name||'Part TCO'}
  function hidePopover(){clearTimeout(hideTimer);$('#part-popover').hidden=true;focusedPart=null;$$('.hotspot').forEach(x=>x.classList.remove('is-active'))}
  function delayedHide(){clearTimeout(hideTimer);hideTimer=setTimeout(hidePopover,165)}
  function showPopover(p,target){
    if(!p)return;
    clearTimeout(hideTimer); focusedPart=p.id;
    $$('.hotspot').forEach(el=>el.classList.toggle('is-active',el.dataset.partId===p.id));
    $('#popover-title').textContent=displayTitle(p);
    $('#popover-sku').textContent=effectiveSKU(p)?`Part Number: ${effectiveSKU(p)}`:'Part Number: Lihat rincian';
    $('#popover-price').textContent=priceString(p);
    $('#popover-description').textContent=p.description||p.desc||'Informasi aksesori TCO.';
    $('#popover-note').textContent=detailNote(p);
    const im=$('#popover-image');im.style.display='block';im.onerror=()=>{im.style.display='none'};im.src=p.image;im.alt=`Foto ${displayTitle(p)}`;
    const pop=$('#part-popover');pop.hidden=false;
    const r=target.getBoundingClientRect();const w=pop.offsetWidth,h=pop.offsetHeight;
    const left=trim(r.left+r.width/2-w/2,10,Math.max(10,innerWidth-w-10));
    const minTop=(document.querySelector('.site-header')?.offsetHeight||document.querySelector('header.topbar')?.offsetHeight||0)+12;
    const top=trim((r.bottom+12+h<=innerHeight)?r.bottom+12:r.top-h-12,minTop,Math.max(minTop,innerHeight-h-12));
    pop.style.left=left+'px';pop.style.top=top+'px';
  }
  function attachInfo(el,p){
    if(hoverDevice){el.addEventListener('mouseenter',()=>showPopover(p,el));el.addEventListener('mouseleave',delayedHide)}
    el.addEventListener('focus',()=>showPopover(p,el));el.addEventListener('blur',delayedHide);
    if(!hoverDevice && el.classList.contains('hotspot'))el.addEventListener('click',e=>{e.stopPropagation();(focusedPart===p.id&&!$('#part-popover').hidden)?hidePopover():showPopover(p,el)});
  }
  $('#part-popover').addEventListener('mouseenter',()=>clearTimeout(hideTimer));
  $('#part-popover').addEventListener('mouseleave',delayedHide);
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('.hotspot,.part-popover'))hidePopover()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')hidePopover()});
  window.addEventListener('scroll',()=>{if(!$('#part-popover').hidden)hidePopover()},{passive:true});
  window.addEventListener('resize',hidePopover);

  function renderHero(){
    const unit=m(),info=meta();const titles=(info.title||unit.name.toUpperCase()).split('|');
    document.title=`${unit.name} — Harga TCO Kalla Toyota`;
    $('#breadcrumb-unit').textContent=unit.name;
    $('#hero-title').innerHTML=H(titles[0])+(titles.length>1?' <em>'+H(titles.slice(1).join(' '))+'</em>':'');
    $('#hero-tagline').textContent=info.tagline||'Explore Toyota Customization Option.';
    $('#hero-category').textContent=unit.category||'Toyota';
    const preview=color()?.front||unit.frontImage||unit.main;
    $('#hero-car').alt=`${unit.name} ${color()?.name||''} tampak depan`;
    $('#hero-image-error').hidden=true;
    imageOrFallback($('#hero-car'),preview,unit.frontImage||unit.main,()=>{$('#hero-image-error').hidden=false});
    const palette=$('#color-panel')||$('#color-list')?.closest('.color-panel');
    if(palette)palette.hidden=colors().length===0;
    $('#color-list').innerHTML=colors().map(c=>`<button type="button" class="color-swatch" data-color="${H(c.key)}" style="--swatch:${H(c.hex)}" aria-label="Warna ${H(c.name)}" aria-pressed="${c.key===chosenColor}"></button>`).join('');
    $('#color-name').textContent=color()?.name||'Foto referensi';
    $$('.color-swatch').forEach(b=>b.addEventListener('click',()=>{
      chosenColor=b.dataset.color;
      // Mengubah hero saja. Explorer selalu putih.
      renderHero();renderCards(allParts());hidePopover();
    }));
  }
  function renderAngles(parts){
    const unit=m(),images=unit.slug==='agya'?(VIEWS[unit.slug]||{}):{front:unit.frontImage||unit.main,rear:unit.rearImage||''};
    const calibrated=unit.slug==='agya';
    const views=[{key:'front',label:'TAMPAK DEPAN',src:images.front||unit.frontImage||unit.main,legacy:calibrated?'':(unit.frontImage||unit.main)},
                 {key:'rear',label:'TAMPAK BELAKANG',src:images.rear||unit.rearImage,legacy:calibrated?'':(unit.rearImage||'')}].filter(v=>v.src||v.legacy);
    const gallery=$('#angle-gallery');gallery.innerHTML='';
    gallery.classList.toggle('single',views.length===1);
    const instruction=$('#explorer-description')||$('.explorer-section .section-heading p');
    if(instruction)instruction.innerHTML=calibrated
       ? 'Tampilan unit selalu <strong>putih</strong> untuk memudahkan identifikasi lokasi part. Arahkan kursor ke titik putih untuk melihat informasi; sentuh titik pada ponsel.'
       : 'Foto unit ditampilkan sebagai <strong>referensi visual</strong>. Titik interaktif belum tersedia karena koordinat aksesori pada model ini belum diverifikasi. Informasi harga tersedia pada daftar part di bawah.';
    for(const v of views){
      const panel=document.createElement('article');panel.className='angle-panel';
      panel.innerHTML=`<div class="angle-panel-top"><span class="angle-name">${v.label}</span><span class="angle-note">${calibrated?'Putih · koordinat terkalibrasi':'Foto referensi · tanpa hotspot'}</span></div><div class="angle-image-space"><img alt="${H(unit.name+' '+v.label)}"><div class="hit-layer"></div><div class="image-missing" hidden>Foto ${H(v.label.toLowerCase())} belum tersedia.<br>Tambahkan file PNG warna putih pada folder unit.</div></div><p class="angle-instruction">${calibrated?'Hover titik putih untuk menampilkan detail part':'Lihat harga dan nomor part pada katalog di bawah'}</p>`;
      gallery.appendChild(panel);
      const img=$('.angle-image-space img',panel),dots=$('.hit-layer',panel),missing=$('.image-missing',panel);
      // Coordinates are percentages relative to the actual raster, not the card.
      const withPos=parts.filter(p=>Array.isArray(p.pos?.[v.key]));
      dots.innerHTML=withPos.map(p=>`<button type="button" class="hotspot" data-part-id="${H(p.id)}" style="--x:${trim(p.pos[v.key][0],1,99)}%;--y:${trim(p.pos[v.key][1],1,99)}%" aria-label="Lihat ${H(displayTitle(p))}"></button>`).join('');
      const byId=new Map(parts.map(p=>[p.id,p]));
      $$('.hotspot',dots).forEach(dot=>attachInfo(dot,byId.get(dot.dataset.partId)));
      const url=v.src;
      if(!url){img.hidden=true;dots.hidden=true;missing.hidden=false;continue}
      imageOrFallback(img,url,v.legacy,()=>{dots.hidden=true;missing.hidden=false});
      img.onload=()=>{img.hidden=false;missing.hidden=true;dots.hidden=false};
    }
  }
  function renderCards(parts){
    const container=$('#tab-content');
    if(tab==='spec'){
      $('#explorer-section').hidden=true;
      container.innerHTML=`<div class="spec-grid"><div class="spec-item"><strong>${H(m().name)}</strong><span>Model kendaraan</span></div><div class="spec-item"><strong>Juli 2026</strong><span>Periode harga PDF TCO</span></div><div class="spec-item"><strong>RTCO After Tax</strong><span>Harga jual pelanggan dalam dokumen sumber</span></div></div>`;
      return;
    }
    $('#explorer-section').hidden=false;
    const visible=parts.filter(p=>tab==='all'||p.kind===tab);
    if(!visible.length){
      container.innerHTML=`<div class="empty-state">${m().slug==='vellfire'?'Untuk Vellfire, PDF Juli 2026 hanya mencantumkan paket Modellista sebesar Rp69.800.000; harga satuan part tidak dicantumkan.':'Belum ada harga satuan dalam kategori ini yang dapat dikonfirmasi.'}</div>`;
      return;
    }
    container.innerHTML=`<div class="parts-grid">${visible.map(p=>`
      <article class="part-card" data-part-id="${H(p.id)}">
        <div class="part-media ${p.image?'':'no-photo'}">${p.image?`<img src="${H(p.image)}" alt="Foto ${H(displayTitle(p))}" loading="lazy">`:''}<span class="media-placeholder" ${p.image?'hidden':''}>Foto part belum tersedia</span></div>
        <div class="part-body"><h3>${H(displayTitle(p))}</h3>
        <span class="part-sku">${H(effectiveSKU(p)?'P/N: '+effectiveSKU(p):p.status==='verify'?'P/N aksesori GR: belum diverifikasi':p.components?'P/N per komponen tercantum di bawah':'P/N tidak tersedia')}</span>
        <span class="price ${p.status?'uncertain':''}">${H(priceString(p))}</span>
        ${p.status==='verify'?`<span class="price-hint">Harga referensi ${H(p.referenceName||'part pada tabel satuan')}: ${H(rupiah(p.referencePrice))}. Nama/nomor part belum terkonfirmasi sama.</span>`:''}
        ${p.priceLabel&&p.status!=='bulletin'&&p.status!=='verify'?`<span class="price-hint">${H(p.priceLabel)}</span>`:''}
        <p>${H(p.description||p.desc||'Informasi aksesori TCO.')}</p>
        ${Array.isArray(p.components)&&p.components.length?`<div class="part-components" aria-label="Rincian komponen dan harga"><strong>Rincian harga komponen</strong>${p.components.map(c=>`<div><span>${H(c.name)} <small>${H(c.sku)}</small></span><b>${H(rupiah(c.price))}</b></div>`).join('')}</div>`:''}
        ${p.photoStatus?`<span class="part-photo-status">${H(p.photoStatus)}</span>`:''}
        ${p.grades?.length?`<div class="part-grade">${grade(p)}</div>`:''}
        </div>
      </article>`).join('')}</div>`;
    // Kartu merupakan informasi statis: tidak ada hover, fokus, klik ataupun popup.
    $$('.part-card',container).forEach(el=>{
      const im=$('img',el);
      if(im)im.onerror=()=>{im.hidden=true;$('.media-placeholder',el).hidden=false};
    });
  }
  function render(){
    const unit=m();if(!colors().some(c=>c.key===chosenColor))chosenColor=meta().heroColor||colors()[0]?.key||'white';
    const parts=allParts();
    $('#unit-switch-label').textContent=unit.name.toUpperCase();
    $('#unit-counter').textContent=`${String(idx+1).padStart(2,'0')} / ${String(CATALOG.length).padStart(2,'0')}`;
    $('#part-count').textContent=parts.length;
    renderHero();renderAngles(parts);renderCards(parts);
    $$('.detail-tabs button').forEach(b=>{const selected=b.dataset.tab===tab;b.classList.toggle('active',selected);b.setAttribute('aria-selected',String(selected))});
  }
  function changeUnit(next,scroll=true){
    idx=(next+CATALOG.length)%CATALOG.length; tab='all';chosenColor=meta().heroColor||'white';hidePopover();
    try{history.pushState(null,'',`detail.html?unit=${encodeURIComponent(m().slug)}`)}catch(_){ }
    render();if(scroll)scrollTo({top:0,behavior:'smooth'});
  }
  $('#prev-unit').addEventListener('click',()=>changeUnit(idx-1));
  $('#next-unit').addEventListener('click',()=>changeUnit(idx+1));
  $$('.detail-tabs button').forEach(b=>b.addEventListener('click',()=>{tab=b.dataset.tab;hidePopover();render()}));
  window.addEventListener('popstate',()=>{const slug=new URLSearchParams(location.search).get('unit');const next=CATALOG.findIndex(x=>x.slug===slug);if(next>=0){idx=next;tab='all';chosenColor='white';render()}});
  let start=null;
  $('#swipe-zone').addEventListener('touchstart',e=>{const t=e.changedTouches[0];start=[t.clientX,t.clientY]},{passive:true});
  $('#swipe-zone').addEventListener('touchend',e=>{if(!start)return;const t=e.changedTouches[0],dx=t.clientX-start[0],dy=t.clientY-start[1];if(Math.abs(dx)>65&&Math.abs(dx)>Math.abs(dy)*1.5)changeUnit(idx+(dx<0?1:-1));start=null},{passive:true});
  // Calibration utility: inspect original image-relative coordinates from the browser console.
  // In devtools run: enableTCOHotspotCalibration(); then click a point on the white image.
  window.enableTCOHotspotCalibration=()=>{
    $$('.angle-image-space img').forEach(img=>img.addEventListener('click',function(e){
      const r=this.getBoundingClientRect();
      const x=+(100*(e.clientX-r.left)/r.width).toFixed(1),y=+(100*(e.clientY-r.top)/r.height).toFixed(1);
      console.log('Koordinat hotspot untuk',this.alt,`[${x},${y}]`);
    }));
    console.info('Kalibrasi aktif: klik pada foto putih untuk menampilkan [x,y] di Console.');
  };
  chosenColor=meta().heroColor||'white';render();
})();
